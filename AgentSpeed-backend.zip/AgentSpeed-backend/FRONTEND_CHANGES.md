# Frontend changes needed for this backend

Make these changes in the frontend folder. They connect the UI to the backend and remove silent fallbacks to fake data.

## 1. Environment

Create `frontend/.env`:

    VITE_API_BASE_URL=http://127.0.0.1:8000

## 2. Stop falling back to fake data on backend errors

In VS Code, press Ctrl+Shift+H (Find and Replace in Files), search the `frontend/src/services` folder, and turn on regex mode (Alt+R).

Find:

    console\.warn\('API error, falling back to mockStorage:', e\);

Replace with:

    if (e?.response) throw e;\n        console.warn('API error, falling back to mockStorage:', e);

This makes HTTP errors (approval refused, SpendGuard blocked, payment failed) reach the user. Fallback now happens only when the backend cannot be reached at all.

## 3. Payments must never fall back to mock data

Replace the whole file `frontend/src/services/paymentService.ts` with:

    import { apiClient } from './api';
    import { Purchase } from '../types';

    export const paymentService = {
      async createPayPalOrder(purchaseId: string): Promise<{ orderId: string; amount: number; currency: string }> {
        const res = await apiClient.post('/paypal/create-order', { purchaseId });
        return res.data;
      },

      async capturePayPalOrder(orderId: string, purchaseId: string): Promise<{
        success: boolean;
        captureId: string;
        purchase: Purchase;
      }> {
        const res = await apiClient.post('/paypal/capture-order', { orderId, purchaseId });
        return res.data;
      },
    };

## 4. Add task execution to the task service

In `frontend/src/services/taskService.ts`, add this method inside the `taskService` object:

    async executeTask(taskId: string): Promise<Task> {
      const res = await apiClient.post<Task>(`/tasks/${taskId}/execute`);
      return res.data;
    },

## 5. Use real execution on the Activation page

In `frontend/src/pages/ActivationPage.tsx`:

- Add `import { taskService } from '../services/taskService';` near the other imports.
- Delete the line `await new Promise((resolve) => setTimeout(resolve, 1800));`
- Replace `await receiptService.generateTaskReceipt(currentTask.id);` with `await taskService.executeTask(currentTask.id);`

## 6. Verify the PayPal button uses the real SDK

Open `frontend/src/components/payments/PayPalCheckoutModal.tsx` and confirm it loads the PayPal JavaScript SDK with your sandbox client ID (`VITE_PAYPAL_CLIENT_ID`) and only calls `paymentService`. I have not checked this file, so please confirm it before recording the demo.

## After the changes

1. Start the backend, then the frontend (`npm install`, `npm run dev`).
2. Create a task with budget 10, analyze, approve both purchases, pay each with a PayPal Sandbox buyer, then open Activation and start execution.
3. If anything still shows mock data, check the browser console for "falling back to mockStorage". Each line there means a request is still going to the fake store.
