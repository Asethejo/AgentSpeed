"""End-to-end test. PayPal is replaced by an in-process fake, so no network or credentials are needed.
Run from the backend folder:  python tests/smoke_test.py"""
import os
import sys
from pathlib import Path

os.environ["DB_PATH"] = ":memory:"
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fastapi.testclient import TestClient  # noqa: E402
from app import paypal  # noqa: E402
from app.main import app  # noqa: E402

ORIGINAL = {"create": paypal.create_order, "capture": paypal.capture_order, "get": paypal.get_order}
ORDERS = {}
MODE = {"capture": "ok"}


def fake_create(amount, currency, custom_id, description):
    oid = f"ORD{len(ORDERS) + 1:04d}"
    ORDERS[oid] = {"amount": amount, "currency": currency, "custom_id": custom_id}
    return {"id": oid, "status": "CREATED"}


def fake_capture(order_id):
    o = ORDERS[order_id]
    if MODE["capture"] == "retryable":
        raise paypal.PayPalError("Buyer has not finished approving.", 409, retryable=True)
    if MODE["capture"] == "definitive":
        raise paypal.PayPalError("Card declined.", 402, retryable=False)
    value = f"{o['amount']:.2f}" if MODE["capture"] == "ok" else "0.01"
    return {"id": order_id, "status": "COMPLETED", "purchase_units": [{
        "custom_id": o["custom_id"],
        "payments": {"captures": [{"id": f"CAP-{order_id}", "status": "COMPLETED",
                                   "amount": {"currency_code": o["currency"], "value": value}}]}}]}


def use_fake_paypal():
    paypal.create_order = fake_create
    paypal.capture_order = fake_capture


def restore_paypal():
    paypal.create_order = ORIGINAL["create"]
    paypal.capture_order = ORIGINAL["capture"]


PROMPT = ("Research five AI startups. Compare their funding, growth, and market opportunities. "
          "You can spend up to $10, but ask me before every purchase.")

with TestClient(app) as c:
    # 1. Health and catalog privacy
    assert c.get("/health").json()["status"] == "ok"
    resources = c.get("/resources").json()
    assert len(resources) == 3
    assert all("demoData" not in r for r in resources), "demo content leaked before payment"
    assert c.get("/resources", params={"category": "APIs"}).json()[0]["id"] == "res-market-trends-api"
    print("1. health + catalog OK")

    # 2. Budget $10 -> dataset + API recommended, report excluded
    use_fake_paypal()
    task = c.post("/tasks", json={"prompt": PROMPT, "budget": 10}).json()
    assert c.post(f"/tasks/{task['id']}/analyze").json()["status"] == "completed"
    recs = c.post(f"/tasks/{task['id']}/recommendations").json()
    selected = sorted(r["resourceId"] for r in recs if r["isSelected"])
    assert selected == ["res-market-trends-api", "res-startup-funding-dataset"], selected
    excluded = [r for r in recs if not r["isSelected"] and r["resourceId"] == "res-premium-research-report"][0]
    assert "Budget exceeded" in excluded["whyRecommended"], excluded["whyRecommended"]
    print("2. budget $10 recommends dataset + API, excludes report:", excluded["whyRecommended"])

    # 3. Validation rejects the over-budget combination
    v = c.post("/spendguard/validate", json={"taskId": task["id"], "resourceIds": [
        "res-startup-funding-dataset", "res-market-trends-api", "res-premium-research-report"]}).json()
    assert v["isValid"] is False and v["blockReason"].startswith("Budget exceeded"), v
    print("3. over-budget set blocked:", v["blockReason"])

    # 4. Create purchases for the two recommended resources; duplicate request refused
    purchases = c.post("/purchases", json={"taskId": task["id"], "resourceIds": selected}).json()
    assert len(purchases) == 2 and all(p["status"] == "pending_approval" for p in purchases)
    assert c.post("/purchases", json={"taskId": task["id"], "resourceIds": selected}).status_code == 409
    print("4. two purchases created; duplicate refused")

    # 5. Payment is refused before human approval
    assert c.post("/paypal/create-order", json={"purchaseId": purchases[0]["id"]}).status_code == 409
    print("5. payment refused before approval")

    # 6. Execution refused while purchases are unpaid
    assert c.post(f"/tasks/{task['id']}/execute").status_code == 409
    print("6. execution refused while unpaid")

    # 7. Approve + pay both, verified on the backend
    for p in purchases:
        assert c.post(f"/purchases/{p['id']}/approve", json={"note": "ok"}).json()["status"] == "approved"
    order_a = c.post("/paypal/create-order", json={"purchaseId": purchases[0]["id"]}).json()
    order_a_again = c.post("/paypal/create-order", json={"purchaseId": purchases[0]["id"]}).json()
    assert order_a["orderId"] == order_a_again["orderId"], "unpaid order should be reused"
    cap = c.post("/paypal/capture-order", json={"orderId": order_a["orderId"], "purchaseId": purchases[0]["id"]})
    assert cap.status_code == 200 and cap.json()["success"] is True, cap.text
    assert cap.json()["purchase"]["status"] == "activated"
    assert cap.json()["purchase"]["activationDetails"]["downloadFormat"] == "JSON"
    again = c.post("/paypal/capture-order", json={"orderId": order_a["orderId"], "purchaseId": purchases[0]["id"]})
    assert again.json().get("alreadyProcessed") is True, "duplicate capture must not re-process"
    order_b = c.post("/paypal/create-order", json={"purchaseId": purchases[1]["id"]}).json()
    cap_b = c.post("/paypal/capture-order", json={"orderId": order_b["orderId"], "purchaseId": purchases[1]["id"]})
    assert cap_b.json()["purchase"]["status"] == "activated"
    print("7. both purchases paid, verified, activated; duplicate capture ignored")

    # 8. Wrong order id for a purchase is refused
    wrong = c.post("/paypal/capture-order", json={"orderId": "NOT-MINE", "purchaseId": purchases[0]["id"]})
    assert wrong.status_code == 409
    print("8. mismatched order refused")

    # 9. Dashboard and transactions reflect real payments
    summary = c.get("/dashboard/summary").json()
    assert summary["totalSpent"] == 7.0, summary
    assert len(c.get("/dashboard/transactions").json()) == 2
    print("9. dashboard total spent $7.00, 2 transactions")

    # 10. Execute the task; report uses only unlocked data
    done = c.post(f"/tasks/{task['id']}/execute").json()
    assert done["status"] == "completed" and done["report"]["startupsComparison"], done
    assert done["report"]["decisionReceiptId"] == f"rcpt-{task['id']}"
    print("10. report generated:", done["report"]["executiveSummary"][:80])

    # 11. Receipt resolves by purchase id and by receipt id; it shows the payment and approvals
    r1 = c.get(f"/purchases/{purchases[0]['id']}/receipt").json()
    r2 = c.get(f"/purchases/rcpt-{task['id']}/receipt").json()
    assert r1["receiptId"] == r2["receiptId"] == f"rcpt-{task['id']}"
    assert r1["paymentRecord"]["status"] == "COMPLETED" and len(r1["humanApprovals"]) == 2
    assert r1["spentAmount"] == 7.0 and r1["selectedCount"] == 2 and r1["rejectedCount"] == 1
    print("11. receipt OK; hash", r1["paymentRecord"]["verificationHash"][:12], "...")

    # 12. Reject flow and budget release
    t2 = c.post("/tasks", json={"prompt": PROMPT, "budget": 10}).json()
    c.post(f"/tasks/{t2['id']}/analyze")
    p2 = c.post("/purchases", json={"taskId": t2["id"], "resourceIds": ["res-startup-funding-dataset"]}).json()[0]
    rej = c.post(f"/purchases/{p2['id']}/reject", json={"reason": "Not needed"}).json()
    assert rej["status"] == "rejected" and rej["rejectReason"] == "Not needed"
    assert c.post(f"/purchases/{p2['id']}/approve", json={}).status_code == 409
    p3 = c.post("/purchases", json={"taskId": t2["id"], "resourceIds": ["res-startup-funding-dataset"]})
    assert p3.status_code == 201, "rejected purchase should allow a new request"
    print("12. reject works; rejected purchase frees its slot")

    # 13. Budget $5: only the dataset is recommended
    t5 = c.post("/tasks", json={"prompt": PROMPT, "budget": 5}).json()
    recs5 = c.post(f"/tasks/{t5['id']}/recommendations").json()
    assert [r["resourceId"] for r in recs5 if r["isSelected"]] == ["res-startup-funding-dataset"]
    print("13. budget $5 recommends only the dataset")

    # 14. Blocked provider: nothing recommended
    tb = c.post("/tasks", json={"prompt": PROMPT, "budget": 10,
                                "blockedProviders": ["Demo Catalog"]}).json()
    recsb = c.post(f"/tasks/{tb['id']}/recommendations").json()
    assert not any(r["isSelected"] for r in recsb)
    cands = c.get(f"/tasks/{tb['id']}").json()["candidates"]
    assert all(any(ck["rule"] == "provider" and ck["status"] == "blocked" for ck in cand["checks"])
               for cand in cands), "every candidate should fail the provider rule"
    print("14. blocked provider excludes everything")

    # 15. Retryable capture failure keeps the purchase approved; definitive failure marks it failed
    tr = c.post("/tasks", json={"prompt": PROMPT, "budget": 10}).json()
    c.post(f"/tasks/{tr['id']}/analyze")
    pr = c.post("/purchases", json={"taskId": tr["id"], "resourceIds": ["res-market-trends-api"]}).json()[0]
    c.post(f"/purchases/{pr['id']}/approve", json={})
    o = c.post("/paypal/create-order", json={"purchaseId": pr["id"]}).json()
    MODE["capture"] = "retryable"
    assert c.post("/paypal/capture-order", json={"orderId": o["orderId"], "purchaseId": pr["id"]}).status_code == 409
    assert c.get(f"/purchases/{pr['id']}").json()["status"] == "approved"
    MODE["capture"] = "definitive"
    declined = c.post("/paypal/capture-order", json={"orderId": o["orderId"], "purchaseId": pr["id"]})
    assert declined.status_code == 402 and "declined" in declined.text.lower(), declined.text
    assert c.get(f"/purchases/{pr['id']}").json()["status"] == "payment_failed"
    MODE["capture"] = "amount_mismatch"
    print("15. retryable keeps approved; definitive marks payment_failed")

    # 16. Amount mismatch from PayPal is never unlocked
    MODE["capture"] = "mismatch"
    o2 = c.post("/paypal/create-order", json={"purchaseId": pr["id"]}).json()
    bad = c.post("/paypal/capture-order", json={"orderId": o2["orderId"], "purchaseId": pr["id"]})
    assert bad.status_code == 400 and "mismatch" in bad.text.lower()
    assert c.get(f"/purchases/{pr['id']}").json()["status"] == "payment_failed"
    print("16. amount mismatch refused, nothing unlocked")

    # 17. Missing PayPal credentials give a clear message (real client, no keys)
    restore_paypal()
    tc = c.post("/tasks", json={"prompt": PROMPT, "budget": 10}).json()
    c.post(f"/tasks/{tc['id']}/analyze")
    pc = c.post("/purchases", json={"taskId": tc["id"], "resourceIds": ["res-market-trends-api"]}).json()[0]
    c.post(f"/purchases/{pc['id']}/approve", json={})
    no_keys = c.post("/paypal/create-order", json={"purchaseId": pc["id"]})
    assert no_keys.status_code == 503 and "credentials are missing" in no_keys.text
    print("17. missing credentials -> 503 with setup message")

print("\nALL 17 CHECKS PASSED")
