"""Gemini writes report wording only. Selection, budgets, and payments never depend on it.
If Gemini is missing or fails, the caller uses clearly labelled fallback text."""
import json
import re

import httpx

from .config import GEMINI_API_KEY, GEMINI_MODEL


def _call(prompt: str) -> str | None:
    if not GEMINI_API_KEY:
        return None
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent"
    try:
        r = httpx.post(
            url,
            headers={"x-goog-api-key": GEMINI_API_KEY, "Content-Type": "application/json"},
            json={
                "contents": [{"parts": [{"text": prompt}]}],
                "generationConfig": {"responseMimeType": "application/json"},
            },
            timeout=40,
        )
        r.raise_for_status()
        parts = r.json()["candidates"][0]["content"].get("parts", [])
        text = "".join(p.get("text", "") for p in parts).strip()
        return text or None
    except Exception:
        return None


def report_text(facts: dict) -> dict | None:
    prompt = (
        "You write the report for AgentSpeed. Use ONLY the facts below, which come from unlocked demo "
        "resources. Say that all figures are simulated. Return ONLY a JSON object with keys: "
        "executiveSummary (string, 2-3 sentences), recommendations (array of 2-4 short strings), "
        "conclusion (string).\n\nFACTS:\n" + json.dumps(facts)
    )
    text = _call(prompt)
    if not text:
        return None
    try:
        data = json.loads(re.sub(r"```(?:json)?", "", text).strip())
    except json.JSONDecodeError:
        return None
    if not isinstance(data, dict):
        return None
    summary, recs, concl = data.get("executiveSummary"), data.get("recommendations"), data.get("conclusion")
    if not (isinstance(summary, str) and summary.strip()
            and isinstance(recs, list) and recs and all(isinstance(x, str) for x in recs)
            and isinstance(concl, str) and concl.strip()):
        return None
    return {
        "executiveSummary": summary.strip(),
        "recommendations": [x.strip() for x in recs][:4],
        "conclusion": concl.strip(),
    }
