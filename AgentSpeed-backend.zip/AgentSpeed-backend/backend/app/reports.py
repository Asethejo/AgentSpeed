"""Builds the task report and the decision receipt. Uses only resources that were activated after payment."""
import hashlib
import json

from . import ai_agent
from .catalog import DEMO_NOTICE
from .common import money, now_iso


def report_id(task_id: str) -> str:
    return f"rcpt-{task_id}"


def build_report(task: dict, used: list[dict]) -> dict:
    startups, indicators = [], []
    for r in used:
        d = r.get("demoData", {})
        startups = d.get("startups", startups)
        indicators = d.get("indicators", indicators)

    key_findings = []
    for s in sorted(startups, key=lambda x: -x["growthScore"])[:3]:
        key_findings.append({
            "title": f"{s['name']} shows strong growth",
            "detail": f"{s['stage']} stage, {s['funding']} raised, valued at {s['valuation']}. {s['marketOpportunity']}.",
            "metric": f"{s['growthScore']}/100 growth",
            "badge": "Top growth",
        })
    if not startups:
        for ind in indicators[:2]:
            key_findings.append({"title": ind["label"], "detail": f"Index {ind['value']} ({ind['change']}).",
                                 "metric": ind["value"]})

    sections = []
    for r in used:
        d = r.get("demoData", {})
        sec = {"title": r["name"], "content": r["description"]}
        if "indicators" in d:
            sec["dataPoints"] = [{"label": i["label"], "value": f"{i['value']} ({i['change']})"}
                                 for i in d["indicators"]]
        if "sections" in d:
            sec["content"] = " ".join(s["content"] for s in d["sections"])
        sections.append(sec)

    comparison = None
    if startups:
        comparison = [{
            "name": s["name"], "founded": s["founded"], "stage": s["stage"], "funding": s["funding"],
            "valuation": s["valuation"], "growthScore": s["growthScore"], "techStack": s["techStack"],
            "marketOpportunity": s["marketOpportunity"],
        } for s in startups]

    facts = {
        "task": task["prompt"],
        "resources": [r["name"] for r in used],
        "startups": startups,
        "indicators": indicators,
    }
    ai = ai_agent.report_text(facts)
    source = "gemini" if ai else "fallback"
    summary = ai["executiveSummary"] if ai else (
        f"Fallback report (AI unavailable). Used {len(used)} unlocked resource(s). All figures are simulated demo data.")
    recommendations = ai["recommendations"] if ai else [
        "Track the fastest-growing companies in the dataset for follow-up.",
        "Verify simulated figures against live sources before any real decision.",
    ]
    conclusion = ai["conclusion"] if ai else (
        "Findings come only from the unlocked simulated resources and are not a real market assessment.")

    return {
        "objective": task["prompt"],
        "completedAt": now_iso(),
        "resourcesUsed": [{"name": r["name"], "provider": r["provider"], "price": r["price"],
                           "category": r["category"]} for r in used],
        "executiveSummary": summary,
        "keyFindings": key_findings,
        "analysisSections": sections,
        "startupsComparison": comparison,
        "recommendations": recommendations,
        "conclusion": conclusion,
        "decisionReceiptId": report_id(task["id"]),
        "source": source,
        "notice": DEMO_NOTICE,
    }


def build_receipt(task: dict, purchases: list[dict]) -> dict:
    report = task.get("report")
    candidates = task.get("candidates", [])
    paid = [p for p in purchases if p["status"] in ("paid", "activated")]
    activated = [p for p in purchases if p["status"] == "activated"]
    selected_count = sum(1 for c in candidates if c["selected"])

    evaluated = [{"name": c["name"], "provider": c["provider"], "price": c["price"], "quality": c["quality"],
                  "selected": c["selected"], "reason": c["reason"]} for c in candidates]
    spend_results = [{"rule": f"{c['name']}: {ck['name']}", "status": ck["status"], "detail": ck["details"]}
                     for c in candidates for ck in c.get("checks", [])]

    approvals = []
    for p in purchases:
        if p.get("approvedAt"):
            approvals.append({"resourceName": p["resourceName"], "status": "approved",
                              "timestamp": p["approvedAt"], "note": p.get("approvalNote") or ""})
        elif p["status"] == "rejected":
            approvals.append({"resourceName": p["resourceName"], "status": "rejected",
                              "timestamp": p.get("rejectedAt") or "", "note": p.get("rejectReason") or ""})

    payments = [{
        "resourceName": p["resourceName"],
        "paypalOrderId": p.get("paypalOrderId"),
        "paypalCaptureId": p.get("paypalCaptureId"),
        "amount": p["amount"],
        "currency": p["currency"],
        "status": "COMPLETED",
        "paidAt": p.get("paidAt"),
    } for p in paid]
    integrity_source = json.dumps(payments, sort_keys=True)
    payment_record = {
        "paypalOrderId": ", ".join(x["paypalOrderId"] for x in payments),
        "paypalCaptureId": ", ".join(x["paypalCaptureId"] or "" for x in payments),
        "amount": money(sum(x["amount"] for x in payments)),
        "currency": "USD",
        "status": "COMPLETED" if payments else "NOT_PAID",
        # SHA-256 integrity fingerprint of the payment records. It is NOT a cryptographic signature.
        "verificationHash": hashlib.sha256(integrity_source.encode()).hexdigest(),
        "paidAt": max((x["paidAt"] or "" for x in payments), default=""),
    }

    activations = [{
        "resourceName": p["resourceName"],
        "activatedAt": p.get("activatedAt"),
        "status": "activated",
        "accessMethod": "Simulated demo vault token",
    } for p in activated]

    return {
        "receiptVersion": 2,
        "receiptId": report_id(task["id"]),
        "taskId": task["id"],
        "taskTitle": task["title"],
        "taskDescription": task["prompt"],
        "budget": task["budget"],
        "spentAmount": money(sum(p["amount"] for p in paid)),
        "currency": task.get("currency", "USD"),
        "createdAt": task["createdAt"],
        "completedAt": task.get("completionDate") or "",
        "evaluatedCount": len(evaluated),
        "selectedCount": selected_count,
        "rejectedCount": len(evaluated) - selected_count,
        "evaluatedResources": evaluated,
        "spendGuardResults": spend_results,
        "humanApprovals": approvals,
        "paymentRecord": payment_record,
        "payments": payments,
        "resourceActivations": activations,
        "taskOutcome": {
            "status": task["status"],
            "keyFindingsCount": len(report["keyFindings"]) if report else 0,
            "reportSummary": report["executiveSummary"][:300] if report else "",
            "verifiedByAgent": bool(report),
        },
        "disclaimer": DEMO_NOTICE + " PayPal Sandbox transactions only.",
    }
