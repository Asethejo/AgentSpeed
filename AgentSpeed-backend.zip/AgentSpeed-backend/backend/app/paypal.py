"""PayPal Orders API v2 (Sandbox only). Credentials stay on the backend."""
import uuid

import httpx

from .config import PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET, PAYPAL_ENV


class PayPalError(Exception):
    def __init__(self, message: str, status_code: int = 502, retryable: bool = True):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.retryable = retryable


def _base() -> str:
    if PAYPAL_ENV != "sandbox":
        raise PayPalError("AgentSpeed only runs against the PayPal Sandbox.", 503, retryable=False)
    return "https://api-m.sandbox.paypal.com"


def _token() -> str:
    if not PAYPAL_CLIENT_ID or not PAYPAL_CLIENT_SECRET:
        raise PayPalError("PayPal sandbox credentials are missing. Add them to backend/.env and restart.",
                          503, retryable=False)
    try:
        r = httpx.post(f"{_base()}/v1/oauth2/token", auth=(PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET),
                       data={"grant_type": "client_credentials"}, timeout=30)
    except httpx.HTTPError:
        raise PayPalError("Could not reach PayPal. Please try again.", 502)
    if r.status_code == 401:
        raise PayPalError("PayPal rejected the sandbox credentials. Check backend/.env.", 503, retryable=False)
    if r.status_code >= 400:
        raise PayPalError("PayPal authentication failed. Please try again.", 502)
    return r.json()["access_token"]


def _headers(token: str, idempotent: bool = False) -> dict:
    h = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    if idempotent:
        h["PayPal-Request-Id"] = str(uuid.uuid4())
    return h


def _issues(r: httpx.Response) -> set[str]:
    try:
        return {d.get("issue", "") for d in r.json().get("details", [])}
    except (ValueError, AttributeError):
        return set()


def create_order(amount: float, currency: str, custom_id: str, description: str) -> dict:
    token = _token()
    body = {
        "intent": "CAPTURE",
        "purchase_units": [{
            "custom_id": custom_id,
            "description": description[:127],
            "amount": {"currency_code": currency, "value": f"{amount:.2f}"},
        }],
    }
    try:
        r = httpx.post(f"{_base()}/v2/checkout/orders", headers=_headers(token, True), json=body, timeout=30)
    except httpx.HTTPError:
        raise PayPalError("Could not reach PayPal to create the order. Please try again.", 502)
    if r.status_code >= 400:
        raise PayPalError(f"PayPal could not create the order (HTTP {r.status_code}).", 502)
    return r.json()


def get_order(order_id: str) -> dict:
    token = _token()
    try:
        r = httpx.get(f"{_base()}/v2/checkout/orders/{order_id}", headers=_headers(token), timeout=30)
    except httpx.HTTPError:
        raise PayPalError("Could not reach PayPal to check the payment. Please try again.", 502)
    if r.status_code == 404:
        raise PayPalError("PayPal no longer has this order. Please start the payment again.", 409, retryable=False)
    if r.status_code >= 400:
        raise PayPalError(f"Could not check the PayPal order (HTTP {r.status_code}).", 502)
    return r.json()


def capture_order(order_id: str) -> dict:
    token = _token()
    try:
        r = httpx.post(f"{_base()}/v2/checkout/orders/{order_id}/capture",
                       headers=_headers(token, True), json={}, timeout=30)
    except httpx.HTTPError:
        # The capture may or may not have happened. Ask PayPal instead of guessing.
        return get_order(order_id)
    if r.status_code in (200, 201):
        return r.json()
    issues = _issues(r)
    if "ORDER_ALREADY_CAPTURED" in issues:
        return get_order(order_id)  # an earlier attempt succeeded
    if "ORDER_NOT_APPROVED" in issues:
        raise PayPalError("This payment is not approved in PayPal yet. Finish the PayPal window, then try again.", 409)
    if "PAYER_ACTION_REQUIRED" in issues:
        raise PayPalError("PayPal needs the buyer to finish an extra step in the PayPal window.", 409)
    if "INSTRUMENT_DECLINED" in issues:
        raise PayPalError("PayPal declined this payment method. Choose another method and try again.", 402)
    if r.status_code == 401:
        raise PayPalError("PayPal authentication expired. Please try again.", 503)
    if r.status_code >= 500:
        raise PayPalError("PayPal is temporarily unavailable. Please try again.", 502)
    raise PayPalError(f"PayPal did not capture this payment (HTTP {r.status_code}).", 400, retryable=False)


def verify_completed(order: dict, expected_order_id: str, expected_custom_id: str,
                     amount: float, currency: str) -> dict:
    """Checks PayPal's own order record. The frontend's word is never used."""
    if order.get("id") != expected_order_id:
        return {"state": "FAILED", "captureId": None, "reason": "PayPal returned a different order"}
    unit = (order.get("purchase_units") or [{}])[0]
    if unit.get("custom_id") not in (None, expected_custom_id):
        return {"state": "FAILED", "captureId": None, "reason": "Order does not belong to this purchase"}
    captures = (unit.get("payments") or {}).get("captures") or []
    if not captures:
        return {"state": "NOT_CAPTURED", "captureId": None, "reason": "PayPal has not captured this order yet"}
    cap = captures[0]
    cid = cap.get("id")
    amt = cap.get("amount") or {}
    if amt.get("currency_code") != currency or amt.get("value") != f"{amount:.2f}":
        return {"state": "FAILED", "captureId": cid, "reason": "Captured amount or currency mismatch"}
    status = cap.get("status")
    if status == "COMPLETED":
        return {"state": "COMPLETED", "captureId": cid, "reason": "Verified"}
    if status == "PENDING":
        return {"state": "PENDING", "captureId": cid, "reason": "Payment is pending review"}
    return {"state": "FAILED", "captureId": cid, "reason": f"Capture status is {status}"}
