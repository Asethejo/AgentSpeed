"""SpendGuard: deterministic policy checks. The AI never calls or overrides this module."""
from . import storage
from .common import money, now_iso, today

# Purchases that count against budgets and daily caps.
SPEND_STATUSES = {"approved", "payment_processing", "payment_failed", "paid", "activated"}


def committed_in_task(task_id: str, exclude_id: str | None = None) -> float:
    """Money already reserved in this task: every purchase that is not rejected."""
    return money(sum(
        p["amount"] for p in storage.all_of("purchase")
        if p["taskId"] == task_id and p["status"] != "rejected" and p["id"] != exclude_id
    ))


def daily_spent(exclude_id: str | None = None) -> float:
    """Money approved today across all tasks."""
    d = today()
    return money(sum(
        p["amount"] for p in storage.all_of("purchase")
        if p["status"] in SPEND_STATUSES and (p.get("approvedAt") or "")[:10] == d and p["id"] != exclude_id
    ))


def _check(rule, name, description, status, details):
    return {
        "id": rule, "name": name, "description": description,
        "status": status, "rule": rule, "details": details, "checkedAt": now_iso(),
    }


def evaluate(task: dict, res: dict, committed: float, daily: float) -> list[dict]:
    amount = money(res["price"])
    budget = money(task["budget"])
    total = money(committed + amount)
    checks = []

    if total <= budget + 1e-9:
        checks.append(_check("budget", "Task budget", "Committed spend must stay within the task budget.",
                             "passed", f"Commits ${total:.2f} of ${budget:.2f}"))
    else:
        checks.append(_check("budget", "Task budget", "Committed spend must stay within the task budget.",
                             "blocked", f"Budget exceeded: would commit ${total:.2f} against a ${budget:.2f} budget"))

    max_single = money(task.get("maxIndividualPurchase") or 4.50)
    if amount <= max_single + 1e-9:
        checks.append(_check("max_single", "Single purchase limit", "One purchase cannot exceed this amount.",
                             "passed", f"${amount:.2f} is within the ${max_single:.2f} limit"))
    else:
        checks.append(_check("max_single", "Single purchase limit", "One purchase cannot exceed this amount.",
                             "blocked", f"Exceeds maximum single purchase of ${max_single:.2f}"))

    cap = task.get("dailyCap")
    if not cap:
        checks.append(_check("daily_cap", "Daily cap", "Approved spend per day.", "passed", "No daily cap set"))
    elif money(daily + amount) <= money(cap) + 1e-9:
        checks.append(_check("daily_cap", "Daily cap", "Approved spend per day.", "passed",
                             f"Daily total ${money(daily + amount):.2f} within ${money(cap):.2f}"))
    else:
        checks.append(_check("daily_cap", "Daily cap", "Approved spend per day.", "blocked",
                             f"Exceeds daily cap of ${money(cap):.2f}"))

    if res["category"] in task.get("allowedCategories", []):
        checks.append(_check("category", "Allowed categories", "Only allowed categories can be bought.",
                             "passed", f"{res['category']} is allowed"))
    else:
        checks.append(_check("category", "Allowed categories", "Only allowed categories can be bought.",
                             "blocked", "Category not allowed by policy"))

    blocked_hit = [b for b in task.get("blockedProviders", []) if b.strip() and b.strip().lower() in res["provider"].lower()]
    if blocked_hit:
        checks.append(_check("provider", "Blocked providers", "Providers on the blocklist are never bought from.",
                             "blocked", f"Provider blocked by policy ({blocked_hit[0]})"))
    else:
        checks.append(_check("provider", "Blocked providers", "Providers on the blocklist are never bought from.",
                             "passed", "Provider is not on the blocklist"))

    if task.get("requireApproval", True):
        checks.append(_check("approval", "Human approval", "Every purchase needs explicit human approval.",
                             "requires_approval", "Human approval required before payment"))
    else:
        checks.append(_check("approval", "Human approval", "Every purchase needs explicit human approval.",
                             "passed", "Approval setting is off for this task"))
    return checks


def first_blocked(checks: list[dict]):
    return next((c for c in checks if c["status"] == "blocked"), None)
