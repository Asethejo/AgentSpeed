"""AgentSpeed API. Routes and JSON shapes match the frontend services in src/services/*.ts."""
from contextlib import asynccontextmanager

from fastapi import Body, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from . import paypal, recommender, reports, spendguard, storage
from .catalog import ALL_CATEGORIES, DEMO_NOTICE, RESOURCES
from .common import age_seconds, money, new_id, now_iso
from .config import (
    APP_NAME, FRONTEND_ORIGINS, GEMINI_API_KEY, MONTHLY_BUDGET,
    ORDER_TTL_SECONDS, PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET, PAYPAL_ENV,
)
from .paypal import PayPalError


@asynccontextmanager
async def lifespan(_app: FastAPI):
    # Keep the catalog in sync with catalog.py on every start.
    with storage.LOCK:
        for r in RESOURCES:
            storage.put("resource", r["id"], r)
    yield


app = FastAPI(title=APP_NAME, lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=FRONTEND_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------- Request models (camelCase, matching the frontend) ----------

class TaskCreate(BaseModel):
    prompt: str = Field(min_length=10, max_length=2000)
    budget: float = Field(gt=0, le=10000)
    currency: str = "USD"
    maxIndividualPurchase: float | None = Field(default=None, gt=0)
    dailyCap: float | None = Field(default=None, gt=0)
    allowedCategories: list[str] | None = None
    blockedProviders: list[str] = Field(default_factory=list)
    requireApproval: bool = True


class ValidateIn(BaseModel):
    taskId: str
    resourceIds: list[str] = Field(min_length=1)


class PurchaseCreateIn(BaseModel):
    taskId: str
    resourceIds: list[str] = Field(min_length=1)


class ApproveIn(BaseModel):
    note: str | None = None


class RejectIn(BaseModel):
    reason: str = ""


class CreateOrderIn(BaseModel):
    purchaseId: str


class CaptureIn(BaseModel):
    orderId: str
    purchaseId: str


# ---------- Helpers (call these only while holding storage.LOCK) ----------

def load_task(task_id: str) -> dict:
    t = storage.get("task", task_id)
    if t is None:
        raise HTTPException(404, "Task not found")
    return t


def load_purchase(purchase_id: str) -> dict:
    p = storage.get("purchase", purchase_id)
    if p is None:
        raise HTTPException(404, "Purchase not found")
    return p


def load_resource(resource_id: str) -> dict:
    r = storage.get("resource", resource_id)
    if r is None or not r.get("isActive", True):
        raise HTTPException(404, f"Resource {resource_id} not found")
    return r


def task_purchases(task_id: str, include_rejected: bool = True) -> list[dict]:
    return [p for p in storage.all_of("purchase")
            if p["taskId"] == task_id and (include_rejected or p["status"] != "rejected")]


def refresh_task_state(t: dict) -> None:
    ps = task_purchases(t["id"], include_rejected=False)
    t["spentAmount"] = money(sum(p["amount"] for p in ps if p["status"] in ("paid", "activated")))
    if t["status"] not in ("executing", "completed"):
        if any(p["status"] == "pending_approval" for p in ps):
            t["status"] = "approving"
        elif any(p["status"] in ("approved", "payment_processing", "payment_failed", "paid") for p in ps):
            t["status"] = "purchasing"
    storage.put("task", t["id"], t)


def purchase_check(p: dict, t: dict, r: dict) -> None:
    """SpendGuard re-check before approval or payment. Raises 409 if the purchase no longer fits."""
    checks = spendguard.evaluate(
        t, r,
        spendguard.committed_in_task(t["id"], exclude_id=p["id"]),
        spendguard.daily_spent(exclude_id=p["id"]),
    )
    blocked = spendguard.first_blocked(checks)
    if blocked:
        p["spendGuardStatus"] = "blocked"
        storage.put("purchase", p["id"], p)
        raise HTTPException(409, f"Blocked by SpendGuard: {blocked['details']}")


def activate(p: dict) -> None:
    p["status"] = "activated"
    p["activatedAt"] = now_iso()
    p["activationDetails"] = {
        "accessUrl": f"https://demo.agentspend.local/vault/{p['resourceId']}",
        "apiKey": "sim-" + new_id("key")[4:],
        "downloadFormat": "JSON",
        "instructions": "SIMULATED demo access. The data is fictional and is not a real vendor credential.",
    }


def dashboard_purchase_status(p: dict) -> bool:
    return p["status"] in ("paid", "activated")


# ---------- System ----------

@app.get("/")
def root():
    return {"message": "AgentSpeed API is running"}


@app.get("/health")
def health():
    return {
        "status": "ok",
        "paypalEnv": PAYPAL_ENV,
        "paypalConfigured": bool(PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET),
        "geminiConfigured": bool(GEMINI_API_KEY),
    }


# ---------- Resources ----------

@app.get("/resources")
def list_resources(category: str | None = None, search: str | None = None, sort: str | None = None):
    rows = [recommender.public_resource(r) for r in recommender.active_resources()]
    if category and category != "All":
        rows = [r for r in rows if r["category"] == category]
    if search:
        q = search.lower()
        rows = [r for r in rows if q in r["name"].lower() or q in r["description"].lower()
                or q in r["provider"].lower()]
    if sort == "price-low":
        rows.sort(key=lambda r: r["price"])
    elif sort == "price-high":
        rows.sort(key=lambda r: -r["price"])
    elif sort in ("quality", "suitability"):
        rows.sort(key=lambda r: -r["qualityScore"])
    return rows


@app.get("/resources/{resource_id}")
def get_resource(resource_id: str):
    return recommender.public_resource(load_resource(resource_id))


# ---------- Tasks ----------

@app.post("/tasks", status_code=201)
def create_task(body: TaskCreate):
    if body.currency != "USD":
        raise HTTPException(400, "Only USD is supported in this version")
    prompt = body.prompt.strip()
    task = {
        "id": new_id("task"),
        "title": prompt if len(prompt) <= 70 else prompt[:67] + "...",
        "prompt": prompt,
        "budget": money(body.budget),
        "currency": "USD",
        "maxIndividualPurchase": money(body.maxIndividualPurchase or 4.50),
        "dailyCap": money(body.dailyCap or 25.00),
        "allowedCategories": body.allowedCategories or ALL_CATEGORIES,
        "blockedProviders": [b.strip() for b in body.blockedProviders if b.strip()],
        "requireApproval": body.requireApproval,
        "status": "created",
        "createdAt": now_iso(),
        "spentAmount": 0.0,
        "resourcesEvaluated": 0,
        "resourcesRecommended": 0,
        "candidates": [],
    }
    with storage.LOCK:
        storage.put("task", task["id"], task)
    return task


@app.get("/tasks")
def list_tasks():
    return sorted(storage.all_of("task"), key=lambda t: t["createdAt"], reverse=True)


@app.get("/tasks/{task_id}")
def get_task(task_id: str):
    return load_task(task_id)


@app.post("/tasks/{task_id}/analyze")
def analyze_task(task_id: str):
    with storage.LOCK:
        t = load_task(task_id)
        if any(p["status"] in ("approved", "paid", "activated", "payment_processing")
               for p in task_purchases(task_id)):
            raise HTTPException(409, "This task already has purchases. Create a new task to change the plan.")
        t["status"] = "analyzing"
        rows = recommender.plan(t)
        t["candidates"] = rows
        t["resourcesEvaluated"] = len(rows)
        t["resourcesRecommended"] = sum(1 for r in rows if r["selected"])
        t["status"] = "recommended"
        storage.put("task", t["id"], t)
    return {"status": "completed", "stepsCompleted": 4}


@app.post("/tasks/{task_id}/recommendations")
def task_recommendations(task_id: str):
    with storage.LOCK:
        t = load_task(task_id)
        rows = recommender.plan(t)
        t["candidates"] = rows
        t["resourcesEvaluated"] = len(rows)
        t["resourcesRecommended"] = sum(1 for r in rows if r["selected"])
        storage.put("task", t["id"], t)
    return [recommender.to_recommendation(task_id, r) for r in rows]


def _validate(t: dict, resources: list[dict]):
    committed = spendguard.committed_in_task(t["id"])
    daily = spendguard.daily_spent()
    checks_all, running, requested = [], committed, 0.0
    for r in resources:
        checks = spendguard.evaluate(t, r, running, money(daily + requested))
        for c in checks:
            checks_all.append({**c, "id": f"{r['id']}:{c['rule']}", "name": f"{r['name']}: {c['name']}"})
        running = money(running + r["price"])
        requested = money(requested + r["price"])
    blocked = spendguard.first_blocked(checks_all)
    return checks_all, committed, requested, blocked


@app.post("/spendguard/validate")
def validate(body: ValidateIn):
    with storage.LOCK:
        t = load_task(body.taskId)
        resources = [load_resource(rid) for rid in dict.fromkeys(body.resourceIds)]
        checks_all, committed, requested, blocked = _validate(t, resources)
    passed = sum(1 for c in checks_all if c["status"] == "passed")
    return {
        "isValid": blocked is None,
        "totalBudget": t["budget"],
        "currentCommitted": committed,
        "requestedAmount": requested,
        "remainingBudget": money(t["budget"] - committed - requested),
        "maxPurchaseLimit": t["maxIndividualPurchase"],
        "dailyCap": t.get("dailyCap") or 0,
        "policies": checks_all,
        "auditSummary": f"{passed} of {len(checks_all)} checks passed. "
                        + ("All requested purchases fit the policy." if blocked is None
                           else f"Blocked: {blocked['details']}"),
        "blockReason": blocked["details"] if blocked else None,
    }


# ---------- Purchases ----------

@app.get("/purchases")
def list_purchases(taskId: str | None = None, status: str | None = None):
    rows = storage.all_of("purchase")
    if taskId:
        rows = [p for p in rows if p["taskId"] == taskId]
    if status:
        rows = [p for p in rows if p["status"] == status]
    return rows


@app.post("/purchases", status_code=201)
def create_purchases(body: PurchaseCreateIn):
    with storage.LOCK:
        t = load_task(body.taskId)
        if len(set(body.resourceIds)) != len(body.resourceIds):
            raise HTTPException(409, "The same resource was listed twice")
        active = {p["resourceId"] for p in task_purchases(t["id"], include_rejected=False)}
        dup = [rid for rid in body.resourceIds if rid in active]
        if dup:
            raise HTTPException(409, f"Already requested in this task: {', '.join(dup)}")
        resources = [load_resource(rid) for rid in body.resourceIds]
        _, _, _, blocked = _validate(t, resources)
        if blocked:
            raise HTTPException(409, f"Blocked by SpendGuard: {blocked['details']}")

        reasons = {c["resourceId"]: c["reason"] for c in t.get("candidates", [])}
        created = []
        for r in resources:
            p = {
                "id": new_id("pur"),
                "taskId": t["id"],
                "taskTitle": t["title"],
                "resourceId": r["id"],
                "resourceName": r["name"],
                "provider": r["provider"],
                "amount": money(r["price"]),
                "currency": r["currency"],
                "status": "pending_approval",
                "recommendationReason": reasons.get(r["id"], "Requested by the user"),
                "remainingBudgetAfter": money(t["budget"] - spendguard.committed_in_task(t["id"]) - r["price"]),
                "spendGuardStatus": "requires_approval" if t["requireApproval"] else "passed",
                "createdAt": now_iso(),
                "transactions": [],
            }
            storage.put("purchase", p["id"], p)
            created.append(p)
        t["status"] = "approving"
        storage.put("task", t["id"], t)
    return created


@app.get("/purchases/{purchase_id}")
def get_purchase(purchase_id: str):
    return load_purchase(purchase_id)


@app.post("/purchases/{purchase_id}/approve")
def approve_purchase(purchase_id: str, body: ApproveIn | None = Body(default=None)):
    with storage.LOCK:
        p = load_purchase(purchase_id)
        if p["status"] == "rejected":
            raise HTTPException(409, "This purchase was rejected")
        if p["status"] != "pending_approval":
            return p  # already approved or paid: approving again changes nothing
        t = load_task(p["taskId"])
        purchase_check(p, t, load_resource(p["resourceId"]))
        p["status"] = "approved"
        p["approvedAt"] = now_iso()
        p["approvalNote"] = body.note if body else None
        p["spendGuardStatus"] = "passed"
        storage.put("purchase", p["id"], p)
        refresh_task_state(t)
    return p


@app.post("/purchases/{purchase_id}/reject")
def reject_purchase(purchase_id: str, body: RejectIn = Body(default=RejectIn())):
    with storage.LOCK:
        p = load_purchase(purchase_id)
        if p["status"] in ("paid", "activated", "payment_processing"):
            raise HTTPException(409, "This purchase is already paid or being paid and cannot be rejected")
        p["status"] = "rejected"
        p["rejectedAt"] = now_iso()
        p["rejectReason"] = body.reason or "Rejected by the user"
        storage.put("purchase", p["id"], p)
        refresh_task_state(load_task(p["taskId"]))
    return p


@app.get("/purchases/{purchase_id}/receipt")
def purchase_receipt(purchase_id: str):
    with storage.LOCK:
        if purchase_id.startswith("rcpt-"):
            task = next((t for t in storage.all_of("task") if reports.report_id(t["id"]) == purchase_id), None)
            if task is None:
                raise HTTPException(404, "Receipt not found")
        else:
            task = load_task(load_purchase(purchase_id)["taskId"])
        return reports.build_receipt(task, task_purchases(task["id"]))


# ---------- PayPal ----------

@app.post("/paypal/create-order")
def create_paypal_order(body: CreateOrderIn):
    with storage.LOCK:
        p = load_purchase(body.purchaseId)
        if p["status"] in ("paid", "activated"):
            raise HTTPException(409, "This purchase is already paid")
        if p["status"] not in ("approved", "payment_failed"):
            raise HTTPException(409, "A human must approve this purchase before payment")
        t = load_task(p["taskId"])
        purchase_check(p, t, load_resource(p["resourceId"]))

        # Reuse an unpaid order that is still valid, so a refresh does not create duplicates.
        if (p["status"] == "approved" and p.get("paypalOrderId") and p.get("paypalOrderCreatedAt")
                and age_seconds(p["paypalOrderCreatedAt"]) < ORDER_TTL_SECONDS):
            return {"orderId": p["paypalOrderId"], "amount": p["amount"], "currency": p["currency"]}

        try:
            order = paypal.create_order(p["amount"], p["currency"], f"purchase-{p['id']}",
                                        f"AgentSpeed: {p['resourceName']}")
        except PayPalError as e:
            raise HTTPException(e.status_code, e.message)

        p["paypalOrderId"] = order["id"]
        p["paypalOrderCreatedAt"] = now_iso()
        p["status"] = "approved"
        p.pop("paymentError", None)
        p["transactions"].append({"orderId": order["id"], "captureId": None, "amount": p["amount"],
                                  "currency": p["currency"], "status": "CREATED", "createdAt": now_iso()})
        storage.put("purchase", p["id"], p)
    return {"orderId": order["id"], "amount": p["amount"], "currency": p["currency"]}


@app.post("/paypal/capture-order")
def capture_paypal_order(body: CaptureIn):
    with storage.LOCK:
        p = load_purchase(body.purchaseId)
        if body.orderId != p.get("paypalOrderId"):
            raise HTTPException(409, "This PayPal order does not belong to this purchase")
        if p["status"] == "activated":
            return {"success": True, "captureId": p.get("paypalCaptureId"), "purchase": p,
                    "alreadyProcessed": True}
        if p["status"] != "approved":
            raise HTTPException(409, f"Purchase is '{p['status']}', not ready for capture")

        try:
            order = paypal.capture_order(body.orderId)
        except PayPalError as e:
            if not e.retryable:
                p["status"] = "payment_failed"
                p["paymentError"] = e.message
                storage.put("purchase", p["id"], p)
            raise HTTPException(e.status_code, e.message)

        verdict = paypal.verify_completed(order, body.orderId, f"purchase-{p['id']}",
                                          p["amount"], p["currency"])
        # Note: if PayPal captured money but verification fails, the purchase is marked failed
        # and needs manual refund in the PayPal dashboard. This should not happen for our own orders.
        if verdict["state"] == "NOT_CAPTURED":
            raise HTTPException(409, "PayPal has not captured this payment yet. Please try again.")
        if verdict["state"] == "PENDING":
            p["status"] = "payment_processing"
            p["paypalCaptureId"] = verdict["captureId"]
            storage.put("purchase", p["id"], p)
            return JSONResponse(status_code=202, content={"success": False, "pending": True,
                                                          "detail": verdict["reason"], "purchase": p})
        if verdict["state"] != "COMPLETED":
            p["status"] = "payment_failed"
            p["paymentError"] = verdict["reason"]
            p["paypalCaptureId"] = verdict["captureId"]
            storage.put("purchase", p["id"], p)
            raise HTTPException(400, verdict["reason"])

        p["paypalCaptureId"] = verdict["captureId"]
        p["paidAt"] = now_iso()
        p["status"] = "paid"
        for tx in p["transactions"]:
            if tx["orderId"] == body.orderId:
                tx["captureId"] = verdict["captureId"]
                tx["status"] = "COMPLETED"
        activate(p)  # unlock only after server-side verification
        storage.put("purchase", p["id"], p)
        refresh_task_state(load_task(p["taskId"]))
    return {"success": True, "captureId": verdict["captureId"], "purchase": p}


# ---------- Task execution and receipts ----------

@app.post("/tasks/{task_id}/execute")
def execute_task(task_id: str):
    with storage.LOCK:
        t = load_task(task_id)
        if t["status"] == "completed":
            return t
        ps = task_purchases(task_id, include_rejected=False)
        if any(p["status"] not in ("paid", "activated") for p in ps):
            raise HTTPException(409, "Approve and pay every requested purchase before executing")
        activated = [p for p in ps if p["status"] == "activated"]
        if not activated:
            raise HTTPException(409, "No resources are activated yet")
        used = [storage.get("resource", p["resourceId"]) for p in activated]
        t["status"] = "executing"
        storage.put("task", t["id"], t)
        t["report"] = reports.build_report(t, used)
        t["status"] = "completed"
        t["completionDate"] = t["report"]["completedAt"]
        storage.put("task", t["id"], t)
    return t


@app.get("/tasks/{task_id}/receipt")
def task_receipt(task_id: str):
    with storage.LOCK:
        t = load_task(task_id)
        return reports.build_receipt(t, task_purchases(task_id))


# ---------- Dashboard ----------

@app.get("/dashboard/summary")
def dashboard_summary():
    purchases = storage.all_of("purchase")
    total_spent = money(sum(p["amount"] for p in purchases if dashboard_purchase_status(p)))
    return {
        "totalTasks": len(storage.all_of("task")),
        "totalSpent": total_spent,
        "availableBudget": money(MONTHLY_BUDGET - total_spent),
        "pendingApprovalsCount": sum(1 for p in purchases if p["status"] == "pending_approval"),
        "monthlyBudget": MONTHLY_BUDGET,
        "budgetTrend": "No prior period yet",
        "spentTrend": "No prior period yet",
        "tasksTrend": "No prior period yet",
    }


@app.get("/dashboard/transactions")
def dashboard_transactions():
    rows = []
    for p in storage.all_of("purchase"):
        if p["status"] not in ("paid", "activated", "payment_failed") or not p.get("paypalOrderId"):
            continue
        t = storage.get("task", p["taskId"])
        ref = p.get("paypalCaptureId") or p["paypalOrderId"]
        rows.append({
            "id": ref,
            "purchaseId": p["id"],
            "taskId": p["taskId"],
            "taskName": t["title"] if t else "",
            "resourceName": p["resourceName"],
            "provider": p["provider"],
            "amount": p["amount"],
            "currency": p["currency"],
            "date": p.get("paidAt") or p.get("createdAt"),
            "paypalRef": ref,
            "status": "failed" if p["status"] == "payment_failed" else "completed",
            "activationStatus": "activated" if p["status"] == "activated"
            else ("pending" if p["status"] == "paid" else "failed"),
        })
    return sorted(rows, key=lambda r: r["date"] or "", reverse=True)
