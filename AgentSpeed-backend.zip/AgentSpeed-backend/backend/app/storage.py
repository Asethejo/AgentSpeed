import json
import sqlite3
import threading

from .config import DB_PATH

# One global lock. Every read-modify-write runs inside `with LOCK:` so two requests
# cannot approve, pay, or capture the same purchase at the same time.
LOCK = threading.RLock()
_conn = sqlite3.connect(DB_PATH, check_same_thread=False)
_conn.execute(
    "CREATE TABLE IF NOT EXISTS docs (kind TEXT NOT NULL, id TEXT NOT NULL, data TEXT NOT NULL, "
    "PRIMARY KEY (kind, id))"
)
_conn.commit()


def get(kind: str, doc_id: str):
    with LOCK:
        row = _conn.execute("SELECT data FROM docs WHERE kind=? AND id=?", (kind, doc_id)).fetchone()
    return json.loads(row[0]) if row else None


def put(kind: str, doc_id: str, obj: dict) -> None:
    with LOCK:
        _conn.execute(
            "INSERT INTO docs (kind, id, data) VALUES (?, ?, ?) "
            "ON CONFLICT(kind, id) DO UPDATE SET data = excluded.data",
            (kind, doc_id, json.dumps(obj)),
        )
        _conn.commit()


def all_of(kind: str) -> list:
    with LOCK:
        rows = _conn.execute("SELECT data FROM docs WHERE kind=? ORDER BY rowid", (kind,)).fetchall()
    return [json.loads(r[0]) for r in rows]
