"""Deterministic resource selection. Ranks by suitability per dollar, then applies SpendGuard in order.
This is a greedy heuristic, not a guaranteed optimum. The AI only writes explanations."""
import re

from . import spendguard, storage
from .common import money

BUDGET_RULES = {"budget", "max_single", "daily_cap"}
PUBLIC_FIELDS = [
    "id", "name", "description", "category", "provider", "price", "currency", "qualityScore",
    "freshness", "benefits", "limitations", "provenance", "sampleDataPreview", "expectedContribution",
]


def public_resource(r: dict) -> dict:
    # demoData is never included here. It is released only after a verified payment and activation.
    return {k: r[k] for k in PUBLIC_FIELDS if k in r}


def active_resources() -> list[dict]:
    return [r for r in storage.all_of("resource") if r.get("isActive", True)]


def tokenize(text: str) -> set[str]:
    return set(re.findall(r"[a-z]+", text.lower()))


def plan(task: dict) -> list[dict]:
    tokens = tokenize(task["prompt"])
    daily = spendguard.daily_spent()
    rows = []
    for r in active_resources():
        matched = [t for t in r["tags"] if t in tokens]
        relevance = len(matched) / len(r["tags"]) if r["tags"] else 0.0
        suitability = round(r["qualityScore"] * relevance, 1)
        vpd = round(suitability / r["price"], 2) if r["price"] else 0.0
        rows.append({"r": r, "matched": matched, "suitability": suitability, "vpd": vpd})
    rows.sort(key=lambda x: (-x["vpd"], x["r"]["price"], x["r"]["id"]))

    committed = 0.0
    out = []
    for row in rows:
        r = row["r"]
        base = {
            **public_resource(r),
            "resourceId": r["id"],
            "suitability": row["suitability"],
            "valuePerDollar": row["vpd"],
            "matched": row["matched"],
            "quality": r["qualityScore"],
        }
        if row["suitability"] <= 0:
            out.append({**base, "selected": False, "status": "excluded",
                        "reason": "No relevant match to the task", "checks": []})
            continue
        checks = spendguard.evaluate(task, r, committed, daily)
        blocked = spendguard.first_blocked(checks)
        if blocked is None:
            committed = money(committed + r["price"])
            out.append({**base, "selected": True, "status": "recommended",
                        "reason": (f"Matches {len(row['matched'])} task topic(s): {', '.join(row['matched'])}. "
                                   f"Quality {r['qualityScore']}/100 with the best suitability per dollar."),
                        "checks": checks})
        else:
            status = "alternative" if blocked["rule"] in BUDGET_RULES else "excluded"
            out.append({**base, "selected": False, "status": status,
                        "reason": blocked["details"], "checks": checks})
    return out


def to_recommendation(task_id: str, row: dict) -> dict:
    return {
        "id": f"rec-{task_id}-{row['resourceId']}",
        "taskId": task_id,
        "resourceId": row["resourceId"],
        "resource": {**{k: row[k] for k in PUBLIC_FIELDS if k in row},
                     "recommendationStatus": row["status"], "suitabilityScore": row["suitability"]},
        "suitabilityScore": row["suitability"],
        "qualityScore": row["quality"],
        "freshness": row["freshness"],
        "whyRecommended": row["reason"],
        "expectedContribution": row["expectedContribution"],
        "benefits": row["benefits"],
        "limitations": row["limitations"],
        "price": row["price"],
        "isSelected": row["selected"],
    }
