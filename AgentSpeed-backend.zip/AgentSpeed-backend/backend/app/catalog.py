# Every resource here is SIMULATED demo data. Companies, prices and figures are fictional.
PROVIDER = "AgentSpend Demo Catalog (simulated)"
DEMO_NOTICE = "SIMULATED DEMO DATA. Companies, prices and figures are fictional."
ALL_CATEGORIES = ["Datasets", "APIs", "Research reports", "Industry insights", "Technical documentation"]

RESOURCES = [
    {
        "id": "res-startup-funding-dataset",
        "name": "Startup Funding Dataset (Demo)",
        "description": "Funding rounds, valuations and growth metrics for fictional AI startups.",
        "category": "Datasets",
        "provider": PROVIDER,
        "price": 4.00,
        "currency": "USD",
        "qualityScore": 86,
        "freshness": "Simulated 2026-Q3",
        "benefits": ["Structured funding and growth data", "Five companies for side-by-side comparison"],
        "limitations": ["Fictional companies only", "No live market feeds"],
        "provenance": "Fictional records created for the AgentSpend demo.",
        "sampleDataPreview": "NovaMind AI | Series B | $42M raised | Growth score 92",
        "expectedContribution": "Supplies funding, valuation and growth figures for the comparison table.",
        "tags": ["startups", "funding", "growth", "dataset", "ai", "research"],
        "isActive": True,
        "demoData": {
            "startups": [
                {"name": "NovaMind AI", "founded": "2023", "stage": "Series B", "funding": "$42M",
                 "valuation": "$310M", "growthScore": 92, "techStack": "LLM orchestration, vector search",
                 "marketOpportunity": "Enterprise agent automation"},
                {"name": "Lumen Labs", "founded": "2025", "stage": "Seed", "funding": "$6M",
                 "valuation": "$48M", "growthScore": 84, "techStack": "Edge inference, SDKs",
                 "marketOpportunity": "Developer tooling for AI apps"},
                {"name": "Parallax Robotics", "founded": "2022", "stage": "Series A", "funding": "$18M",
                 "valuation": "$150M", "growthScore": 88, "techStack": "Computer vision, simulation",
                 "marketOpportunity": "Warehouse robotics automation"},
                {"name": "Quorum Data", "founded": "2019", "stage": "Series C", "funding": "$75M",
                 "valuation": "$620M", "growthScore": 71, "techStack": "Data pipelines, governance",
                 "marketOpportunity": "AI data infrastructure"},
                {"name": "Tessera Health AI", "founded": "2024", "stage": "Series A", "funding": "$22M",
                 "valuation": "$180M", "growthScore": 79, "techStack": "Clinical NLP, privacy tooling",
                 "marketOpportunity": "Healthcare documentation AI"},
            ]
        },
    },
    {
        "id": "res-market-trends-api",
        "name": "Market Trends API (Demo)",
        "description": "Simulated industry indicators for AI market momentum.",
        "category": "APIs",
        "provider": PROVIDER,
        "price": 3.00,
        "currency": "USD",
        "qualityScore": 78,
        "freshness": "Simulated 2026-Q3",
        "benefits": ["Quarter-over-quarter indicators", "Easy to cite in a report"],
        "limitations": ["Three indicators only", "Simulated values"],
        "provenance": "Simulated indicator feed created for the demo.",
        "sampleDataPreview": "Enterprise AI tooling demand index: 128 (+22% QoQ)",
        "expectedContribution": "Adds market momentum indicators to the findings.",
        "tags": ["market", "trends", "industry", "growth", "indicators"],
        "isActive": True,
        "demoData": {
            "indicators": [
                {"label": "Enterprise AI tooling demand", "value": "128", "change": "+22% QoQ"},
                {"label": "AI agent platform funding", "value": "91", "change": "+14% QoQ"},
                {"label": "Developer tools adoption", "value": "74", "change": "flat QoQ"},
            ]
        },
    },
    {
        "id": "res-premium-research-report",
        "name": "Premium Research Report (Demo)",
        "description": "Simulated market analysis of AI opportunities and risks.",
        "category": "Research reports",
        "provider": PROVIDER,
        "price": 5.00,
        "currency": "USD",
        "qualityScore": 90,
        "freshness": "Simulated 2026-Q3",
        "benefits": ["Narrative market analysis", "Covers risks as well as opportunities"],
        "limitations": ["Narrative only, no raw data", "Simulated analysis"],
        "provenance": "Simulated analysis written for the demo.",
        "sampleDataPreview": "Enterprise agent platforms show the strongest growth momentum.",
        "expectedContribution": "Adds analyst-style commentary on opportunities and risks.",
        "tags": ["market", "research", "analysis", "opportunities", "competitor", "report"],
        "isActive": True,
        "demoData": {
            "sections": [
                {"title": "Growth momentum",
                 "content": "Enterprise agent platforms show the strongest growth momentum in the simulated data."},
                {"title": "Crowded segments",
                 "content": "Developer tooling is crowded and growing slowly."},
                {"title": "Regulatory risk",
                 "content": "Healthcare AI attracts later-stage capital but carries regulatory risk."},
            ]
        },
    },
]
