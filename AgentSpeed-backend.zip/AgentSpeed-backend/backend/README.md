# AgentSpeed Backend

FastAPI backend for the AgentSpeed frontend. It enforces spending policies, requires human approval, verifies PayPal Sandbox payments on the server, and unlocks resources only after verification.

All catalog resources, providers, prices and figures are simulated demo data. Only the PayPal transactions are real Sandbox transactions when credentials are configured.

## Setup (Windows, VS Code terminal)

    cd backend
    python -m venv venv
    venv\Scripts\activate
    pip install -r requirements.txt
    copy .env.example .env
    uvicorn app.main:app --reload

Open http://127.0.0.1:8000/docs for the interactive API. Health check: http://127.0.0.1:8000/health

Edit `backend/.env` with your PayPal Sandbox client ID and secret. `GEMINI_API_KEY` is optional. Without it, reports use clearly labelled fallback text.

## Tests

    cd backend
    python tests/smoke_test.py

The test replaces PayPal with an in-process fake, so it needs no credentials. It covers budgets, SpendGuard, approval, payment verification, duplicate captures, failure handling, reports and receipts. Expected last line: `ALL 17 CHECKS PASSED`.

## Safety design

- SpendGuard is deterministic code. Gemini only writes report wording and cannot change selections, amounts or payments.
- Every purchase needs human approval, and SpendGuard runs again at approval time and before payment.
- The backend creates and captures PayPal orders and checks PayPal's own record (status, amount, currency, purchase ID). The frontend's word is never used.
- A completed capture is never captured or unlocked twice.
- Resource content (`demoData`) is never returned until a purchase is paid and activated.
- All state changes run under one lock so concurrent requests cannot double-approve or double-pay.

## Known limitations

- Greedy selection by suitability per dollar, not a guaranteed optimum.
- Storage is a single SQLite file. Fine for a demo, not for production.
- If PayPal captures money but verification fails, the purchase is marked failed and must be refunded manually in the PayPal dashboard. This should not happen for orders this backend creates.
- Activation is simulated: access URLs and tokens are labelled demo values.
- Only USD is supported.
